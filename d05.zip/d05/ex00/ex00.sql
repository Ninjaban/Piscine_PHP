CREATE DATABASE db_elemarch;
